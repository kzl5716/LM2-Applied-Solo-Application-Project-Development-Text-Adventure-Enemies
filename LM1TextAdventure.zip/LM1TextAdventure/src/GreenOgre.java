public class GreenOgre extends Ogre{
    public GreenOgre(){
        super("Green Ogre", "Green", 35, 20);
    }
}
