public class GiantSpider extends Enemy{
    public GiantSpider(){
        super("Giant Spider", 2,10);
    }
}
