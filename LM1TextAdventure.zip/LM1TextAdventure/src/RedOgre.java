public class RedOgre extends Ogre{
    public RedOgre(){
        super("Red Ogre", "Red", 30, 25);
    }
}
