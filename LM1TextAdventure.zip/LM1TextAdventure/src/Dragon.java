public class Dragon extends Enemy{
    public Dragon(){
        super("Dragon", 100, 50);
    }
}
