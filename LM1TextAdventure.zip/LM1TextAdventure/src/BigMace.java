public class BigMace extends Mace{
    public BigMace() {
        super("Big Mace","Big","An oversized mace. Very heavy and hard to swing.",120,45);
    }
}
