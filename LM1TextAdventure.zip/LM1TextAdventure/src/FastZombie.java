public class FastZombie extends Zombie{
    public FastZombie(){
        super("Fast Zombie", "Fast", 20,20);
    }
}
