public class Arrow extends Weapon{

    public Arrow(){
        super("Bow & Arrow", "Bow and Arrow. Somewhat more dangerous than a Dagger", 11,31);

    }

}
