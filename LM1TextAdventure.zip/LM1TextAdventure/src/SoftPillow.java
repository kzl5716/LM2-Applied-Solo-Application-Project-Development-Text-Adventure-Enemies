public class SoftPillow extends Pillow{
    public SoftPillow() {
        super("Soft Pillow","Soft","An extremely soft pillow made out of memory foam.",5,1);
    }
}
