public class SlowZombie extends Zombie{
    public SlowZombie(){
        super("Slow Zombie", "Slow", 25,15);
    }
}
