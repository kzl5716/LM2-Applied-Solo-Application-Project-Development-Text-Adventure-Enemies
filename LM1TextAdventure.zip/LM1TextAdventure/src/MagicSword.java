public class MagicSword extends Sword{
    public MagicSword() {
        super("Magic Sword","Magic - Lightning","Sword imbued with Magical properties. Electricity flows through the sword.",100,60);
    }

}