public class SpotDog extends Dog{
    public SpotDog(){
        super("Spot Dog", "Spot", 15, 10);
    }
}
